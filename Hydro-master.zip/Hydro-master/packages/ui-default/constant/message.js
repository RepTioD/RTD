export const FLAG_UNREAD = 1;
export const FLAG_ALERT = 2;
