# Background
Special for beginners, ^_^

# Description
Given two integers x and y, print the sum.

# Format

## Input
Two integers x and y, satisfying $0\leq x,y\leq 32767$ .

## Output
One integer, the sum of x and y.

# Samples

```input1
123 500
```

```output1
623
```

# Limitation
1s, 1024KiB for each test case.
