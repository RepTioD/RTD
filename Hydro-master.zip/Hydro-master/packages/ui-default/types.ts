/* eslint-disable @typescript-eslint/no-unused-vars */
declare let UserContext: any;
declare let UiContext: any;
declare let Hydro: any;
// eslint-disable-next-line camelcase
declare let node_modules: any;
