export default class VJ4 {
    constructor() {
        console.log('新版本不再支持 VJ4。请降级至 hydrojudge@2.5.21 或迁移到 Hydro。');
        console.log('详细文档： https://hydro.js.org/ ');
        process.exit(1);
    }
}
