module.exports = require('./src/service');
